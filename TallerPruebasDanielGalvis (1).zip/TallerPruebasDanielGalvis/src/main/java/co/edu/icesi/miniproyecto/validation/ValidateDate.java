package co.edu.icesi.miniproyecto.validation;

public interface ValidateDate {

}
