package co.edu.icesi.miniproyecto.model;

public enum UserType {
	admin, operador
}
