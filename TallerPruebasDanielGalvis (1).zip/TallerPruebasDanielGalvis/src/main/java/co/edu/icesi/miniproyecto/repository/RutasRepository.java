package co.edu.icesi.miniproyecto.repository;

import org.springframework.data.repository.CrudRepository;

import co.edu.icesi.miniproyecto.model.Tmio1Ruta;

public interface RutasRepository extends CrudRepository<Tmio1Ruta, Integer> {

}
