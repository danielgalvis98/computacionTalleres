package com.taller3.sistemamio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TallerPruebasDanielGalvisApplication {

	public static void main(String[] args) {
		SpringApplication.run(TallerPruebasDanielGalvisApplication.class, args);
	}

}
